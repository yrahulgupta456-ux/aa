// Cycles through a data-covers list of image URLs on any element that has
// one, crossfading between them. Used for the collections grid covers and
// the collection spotlight hero, so a category shows a rotating preview of
// what's actually inside it instead of one fixed (often missing) image.
(function () {
  function startRotator(el, intervalMs) {
    var urls;
    try {
      urls = JSON.parse(el.getAttribute("data-covers") || "[]");
    } catch (e) {
      urls = [];
    }
    if (!urls.length) return;

    var img = el.querySelector("img.cover-img, img.spotlight-img");
    if (!img) return;
    // The spotlight hero also has a blurred backdrop copy of the image;
    // keep it in sync with whatever the foreground image is showing.
    var backdrop = el.querySelector(".spotlight-backdrop");

    if (urls.length === 1) {
      img.src = urls[0];
      if (backdrop) backdrop.style.backgroundImage = "url('" + urls[0] + "')";
      return;
    }

    var i = urls.indexOf(img.getAttribute("src"));
    if (i < 0) i = 0;

    setInterval(function () {
      i = (i + 1) % urls.length;
      img.style.opacity = 0;
      if (backdrop) backdrop.style.opacity = 0;
      setTimeout(function () {
        img.src = urls[i];
        img.style.opacity = 1;
        if (backdrop) {
          backdrop.style.backgroundImage = "url('" + urls[i] + "')";
          backdrop.style.opacity = 1;
        }
      }, 350);
    }, intervalMs);
  }

  document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".album-cover[data-covers]").forEach(function (el) {
      // Stagger each card slightly so a whole grid doesn't flip in unison.
      // Slowed down from ~2.2-3s — that read as constant blinking.
      var delay = 4500 + Math.random() * 1500;
      startRotator(el, delay);
    });
    document.querySelectorAll(".spotlight-hero[data-covers]").forEach(function (el) {
      // Slowed down from 3.8s for the same reason.
      startRotator(el, 6500);
    });
  });
})();
