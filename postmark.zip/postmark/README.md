# Postmark

A small self-hosted photo & video library for your own trip/family media —
built to run on your phone under Termux, no cloud, no Discord.

## Set up on Termux (Android)

Open Termux and run:

```bash
pkg update
pkg install python ffmpeg -y
```

`ffmpeg` is optional but recommended — it's used to generate thumbnails for
videos. Without it, videos still play, they just show a generic icon in the
grid until you open one.

Copy the `postmark` folder onto your phone (e.g. with Termux's storage
access, or by unzipping a download into `~/postmark`), then:

```bash
cd postmark
pip install -r requirements.txt
python app.py
```

The first run creates the database and an empty `library/` folder next to
`app.py`. Leave the terminal running, then open a browser (on the same phone,
or any device on the same Wi-Fi) and go to:

```
http://localhost:8080          # on the phone itself
http://<phone-ip-address>:8080 # from another device on the same network
```

Find your phone's local IP with `ifconfig` or in Wi-Fi settings.

## Adding your media

**Fresh install has an empty library on purpose** — nothing ships with sample
photos. Get your own media in one of two ways:

1. **Point Postmark at a folder you already have**, instead of copying
   anything. Set `POSTMARK_LIBRARY` before starting the app:

   ```bash
   export POSTMARK_LIBRARY=~/storage/downloads/discord-media
   python app.py
   ```

   If your photos live in Android's shared storage (Camera roll, Downloads,
   etc.) rather than Termux's private folder, run `termux-setup-storage`
   once first (grants Termux access, creates `~/storage/`), then point
   `POSTMARK_LIBRARY` at e.g. `~/storage/dcim/Camera` or
   `~/storage/downloads/<your-discord-export-folder>`. Files are read in
   place — nothing is duplicated. Every time you add files there, tap
   **Rescan** on the site (or restart the app) to pick them up.

2. **Upload from the site** — tap **Add media**, pick files from your phone.
   These get copied into the library folder directly.

Supported formats: jpg, png, gif, webp, bmp, heic for photos; mp4, mov,
webm, mkv, avi, m4v for video.

## Catalog, categories, channels

Navigation is now three levels, matching how the media was organized on
Discord:

- **Catalog** (the home page) — every category, plus any channels you
  haven't sorted into one yet.
- **Category** — a group of channels (e.g. everything under a Discord
  category). Create one from the box at the top of the Catalog page.
- **Channel** (a "collection") — the actual grid of photos/videos. Assign a
  channel to a category from a dropdown on the channel's own page.

Feeding (auto-advancing full-screen playback) works at every level: a
channel, a whole category, favorites, or everything.

## Leaderboard

Every time you run a Feed on a specific channel for at least 30 seconds, it
earns points (1 base + 1 per minute fed + 0.1 per item shown), tallied
forever. **Leaderboard** in the sidebar shows which channels and categories
you go back to feed the most — a personal stat, carried over from the old
Discord bot's `!totalvotes` board.

## Kept intentionally simple

To stay reliable on Termux, there's no photo editor (crop/rotate/filters) —
just **move**, **copy**, and **delete** on each item's page.

## Keeping it running

To keep Postmark running in the background on Termux, install `tmux` (or
`termux-wake-lock` to stop Android from killing the process) and run it there:

```bash
pkg install tmux
tmux new -s postmark
python app.py
# Ctrl+B then D to detach; `tmux attach -t postmark` to come back
```

## Project layout

```
app.py            Flask routes
db.py             SQLite schema + connection helper
scanner.py        Library folder scanning + thumbnail generation
templates/        Jinja2 templates (catalog, category, channel, media detail, upload, etc.)
static/           CSS and JS
library/          Your actual photos & videos live here (gitignored)
.data/            SQLite DB + generated thumbnails (gitignored)
```

## Notes

- This is meant for a single person on a trusted local network — there's no
  login. If you ever expose it beyond your own Wi-Fi, put it behind a proper
  reverse proxy with authentication first.
- There's no facial recognition — it was left out on purpose since the
  libraries for it don't install cleanly on Termux, and it wasn't needed
  for a personal trip/family library. Tags cover the "who's in this photo"
  use case well enough for a library this size.
